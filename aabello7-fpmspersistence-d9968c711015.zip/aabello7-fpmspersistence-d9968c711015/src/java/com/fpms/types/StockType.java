/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.fpms.types;


/**
 *
 * @author aabello
 */
public enum StockType {
    IN, OUT
   
}

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.fpms.util.crud;

/**
 *
 * @author faizbash
 */
public enum ParameterType {
     WITH, AND, OR
}